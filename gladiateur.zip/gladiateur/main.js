class Guerrier {
    constructor(name, santé, attaque, précision) {
        this.name = name;
        this.santé = santé;
        this.attaque = attaque;
        this.précision = précision;
    }

    attackOpponent(opponent) {
        if (Math.random() < this.précision) {
            opponent.santé -= this.attaque;
            console.log(`${this.name} attaque ${opponent.name} et lui inflige ${this.attaque} points de dégâts.`);
        } else {
            console.log(`${this.name} rate son attaque contre ${opponent.name}.`);
        }
    }
}

const guerrier1 = new Guerrier('Gladiateur', 70, 20, 0.7);
const guerrier2 = new Guerrier('Berserker', 100, 10, 0.5);

while (guerrier1.santé > 0 && guerrier2.santé > 0) {
    guerrier1.attackOpponent(guerrier2);

    if (guerrier2.santé <= 0) {
        console.log(`${guerrier2.name} est vaincu. ${guerrier1.name} est le vainqueur !`);
        break;
    }

    guerrier2.attackOpponent(guerrier1);

    if (guerrier1.santé <= 0) {
        console.log(`${guerrier1.name} est vaincu. ${guerrier2.name} est le vainqueur !`);
        break;
    }
}