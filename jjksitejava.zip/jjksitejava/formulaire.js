document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    resetForm();

    let isValid = true;
    let errorMessage = '';

    const pseudo = document.getElementById('pseudo');
    if (pseudo.value.length < 6) {
        pseudo.classList.add('invalid');
        errorMessage += 'Le pseudo doit comporter au moins 6 caractères.\n';
        isValid = false;
    } else {
        pseudo.classList.add('valid');
    }

    const email = document.getElementById('email');
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email.value)) {
        email.classList.add('invalid');
        errorMessage += 'L\'email n\'est pas valide.\n';
        isValid = false;
    } else {
        email.classList.add('valid');
    }

    const password = document.getElementById('password');
    if (password.value.length < 8) {
        password.classList.add('invalid');
        errorMessage += 'Le mot de passe doit comporter au moins 8 caractères.\n';
        isValid = false;
    } else {
        password.classList.add('valid');
    }

    const confirmPassword = document.getElementById('confirmPassword');
    if (confirmPassword.value !== password.value) {
        confirmPassword.classList.add('invalid');
        errorMessage += 'Les mots de passe ne correspondent pas.\n';
        isValid = false;
    } else {
        confirmPassword.classList.add('valid');
    }

    const questionAnswered = document.querySelector('input[name="question"]:checked');
    if (!questionAnswered) {
        errorMessage += 'Vous devez répondre à la question.\n';
        isValid = false;
    }

    if (isValid) {
        document.getElementById('confirmation-message').style.display = 'block';
        document.getElementById('confirmation-message').innerHTML = 'Inscription réussie !';
    } else {
        document.getElementById('error-message').style.display = 'block';
        document.getElementById('error-message').innerHTML = errorMessage;
    }
});

function resetForm() {
    const fields = document.querySelectorAll('input');
    fields.forEach(field => {
        field.classList.remove('valid', 'invalid');
    });
    document.getElementById('error-message').style.display = 'none';
    document.getElementById('confirmation-message').style.display = 'none';
}