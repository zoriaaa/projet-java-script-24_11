let panier = [];

function ajouterAuPanier(nom, prix) {
    panier.push({ nom, prix });
    console.log(`Ajouté au panier: ${nom}, Prix: ${prix}€`);
    afficherPanier();
}

function afficherPanier() {
    const panierContainer = document.getElementById("panier-container");
    panierContainer.innerHTML = "";

    panier.forEach(item => {
        const itemElement = document.createElement("div");
        itemElement.classList.add("panier-item");
        itemElement.textContent = `${item.nom} - ${item.prix}€`;
        panierContainer.appendChild(itemElement);
    });

    const total = panier.reduce((total, item) => total + item.prix, 0);
    const totalElement = document.getElementById("total");
    totalElement.textContent = `Total: ${total}€`;
}

function toggleTheme() {
    document.body.classList.toggle('dark-theme');
}